<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="description" content="require freight forwarding, customs clearance, transportation, warehousing, 
      distribution, or project cargo shipments">
<meta name="keywords" content="cargo, export, import, export import, cargo surabaya, transportation, warehousing,
      cargo shipments, freight forwarding, distribution">
<meta name="author" content="DapurMedia">

<link rel="stylesheet" type="text/css" href="css/reset.css" />
<link rel="stylesheet" type="text/css" href="css/layout.css"/>
<link rel="stylesheet" type="text/css" href="css/supersized.css"/>
<link rel="stylesheet" type="text/css" href="css/supersized.shutter.css"/>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/jqueryslidemenu.css"/>

<link href="css/sudo.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="css/fancybox/jquery.fancybox-1.3.4.css" media="screen" />

<script type="text/javascript" src="js/lib/jquery-1.10.1.min.js"></script>
<script type="text/javascript" src="js/lib/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/source/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="js/source/jquery.fancybox.css?v=2.1.5" media="screen" />


<script type="text/javascript" src="js/jquery-1.7.1.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/supersized.3.2.7.js"></script>
<script type="text/javascript" src="js/supersized.shutter.js"></script>
<script type="text/javascript" src="js/jqueryslidemenu.js"></script>
<script type="text/javascript" src="js/jquery.sudoSlider.js"></script>
<script type="text/javascript" src="js/custom.js"></script>

        <!-- <script type="text/javascript" src="js/contact.js"></script>  -->
<script type="text/javascript" src="css/fancybox/jquery.fancybox-1.3.4.js"></script>

<!--[if lt IE 9]>
<script src="../../../../html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<link href='../../../../fonts.googleapis.com/css@family=Oswald_3A300,400,500,700' rel='stylesheet' type='text/css' />
