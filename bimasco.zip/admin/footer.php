<div id="footer">
    <div class="container">
        <p class="text-muted">Copyright &COPY; <?php echo date("Y"); ?> | All Right Reserve Bimasco - 
            <a href="http://www.dapurmedia.com"><img src="bootstrap/img/logo.png" style="width: 95px; height: 32px; margin-top: -15px;"></a></p>
    </div>
</div>